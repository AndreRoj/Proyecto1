
package Clases;

import Funciones.Matriz;
import Funciones.Global;

public class Hormigas {
    private Ciudad ciudadinicial;
    private Ciudad ciudadactual;
    private Ciudad ciudadfinal;
    private boolean prueba;
    private int intento;
    private Matriz matriz;
    private Camino camino;
    private Global global;

    public Hormigas(Ciudad ciudadinicial, Ciudad ciudadfinal, Matriz matriz) {
        this.ciudadinicial = ciudadinicial;
        this.ciudadactual = ciudadinicial;
        this.ciudadfinal = ciudadfinal;
        this.camino = null;
        this.global = global;
        this.matriz = matriz;
        this.prueba = false;
        this.intento = 0;
    }

    public Ciudad getCiudadinicial() {
        return ciudadinicial;
    }

    public void setCiudadinicial(Ciudad ciudadinicial) {
        this.ciudadinicial = ciudadinicial;
    }

    public Ciudad getCiudadactual() {
        return ciudadactual;
    }

    public void setCiudadactual(Ciudad ciudadactual) {
        this.ciudadactual = ciudadactual;
    }

    public Ciudad getCiudadfinal() {
        return ciudadfinal;
    }

    public void setCiudadfinal(Ciudad ciudadfinal) {
        this.ciudadfinal = ciudadfinal;
    }

    public Camino getCamino() {
        return camino;
    }

    public void setCamino(Camino camino) {
        this.camino = camino;
    }

    public Global getGlobal() {
        return global;
    }

    public void setGlobal(Global global) {
        this.global = global;
    }

    public Matriz getMatriz() {
        return matriz;
    }

    public void setMatriz(Matriz matriz) {
        this.matriz = matriz;
    }

    public boolean isPrueba() {
        return prueba;
    }

    public void setPrueba(boolean prueba) {
        this.prueba = prueba;
    }

    public int getIntento() {
        return intento;
    }

    public void setIntento(int intento) {
        this.intento = intento;
    }
    
    //sumatoria que se pide en el calculo de posibilidades de eleccion de camino
    public float sumatoria(){
        float[] distancia = getMatriz().buscar(getCiudadactual().getName()-1);
        float a = 0;
        float r = (float)1/(Global.getListaciudades().getSize());
        //System.out.println(r);
        //System.out.println(distancia.length);
        for (int i = 0; i < distancia.length; i++) {
            if(distancia[i] == 0){
                a+=0;
            }else{
                float parte = potencia(r, getGlobal().getImporfermonas());
                //System.out.println("parte: "+ parte );
                //System.out.println("distancia infinito: " + distancia[i]);
                float n = (float) 1/distancia[i];
                //System.out.println("n: "+n);
                float parte2 = potencia(n, getGlobal().getVisibilidad());
                //System.out.println("a antes: " + a);
                a += parte*parte2;
                //System.out.println("a despues: "+a);
            }
        }
        return a;  
    }
    
    //metodo para elevar, no podemos usar Math pow, por eso se creo
    public float potencia(float numero, int elevado){
        int a = 1;
        float b = numero;
        //System.out.println("antes");
        //System.out.println(b);
        while(a<elevado){
            b *= numero;   
            a++;
        }
        //System.out.println("despues");
       // System.out.println(b);
        return b; 
    } 
    
    //calculo de la eleccion de camino tomando la formula dada, tambien ya aumenta la cantidad de fermonas de ese camino 
    public void eleccioncamino(){
        int d = getCiudadactual().getName();
        double random = Math.random();
        float[] distancia = getMatriz().buscar(getCiudadactual().getName()-1);
        //System.out.println(random);
        float a = this.sumatoria();
        ListaCaminos lista = global.getListacaminos().buscarCiudadName(getCiudadactual().getName());
        //sacar de la lista los caminos que ya en la matriz tienen valor de cero
        //System.out.println("antes");
        //lista.print();
        NodoCamino pointer = lista.getHead();
        //System.out.println("verificar");
        while(pointer != null){
            float value = getMatriz().getMatrix()[(pointer.getElement().getCiudadinicial().getName())-1][(pointer.getElement().getCiudadfinal().getName())-1];
            float value2 = getMatriz().getMatrix() [pointer.getElement().getCiudadfinal().getName()-1][pointer.getElement().getCiudadinicial().getName()-1];
            if(lista.getSize() != 1){
                if(value == (float)0 || value2 == (float)0){
                    //System.out.println("la lista es de este tamaño: "+lista.getSize());
                    lista.deleteCaminoEspecifico(pointer.getElement());
                    pointer = lista.getHead();
                }else{
                    //System.out.println("ander");
                    pointer = pointer.getNext();
                }
            }else{
                //System.out.println("caballo");
                setPrueba(true);
                break;
            }
        }
        while(pointer != null){
            if(lista.getSize() != 1){
                if(pointer.getElement().getCiudadfinal().getName() == d){
                   lista.deleteCaminoEspecifico(pointer.getElement());
                   pointer = lista.getHead();
                }else{
                    pointer = pointer.getNext();
                }
            }else{
               break;       
            }
        }
        //System.out.println("lista: " +lista.getSize());
        //System.out.println("despues");
        //lista.print();
        float [] resultados = new float [lista.getSize()];
        for (int i = 0; i < lista.getSize(); i++){
            if(distancia[i]!= 0){
            float parte = this.potencia(lista.recorrer(i).getCantidadfermona(), getGlobal().getImporfermonas());
            //System.out.println("parte: "+parte);
            float n =(float) 1/distancia[i];
            float parte2 = this.potencia(n, getGlobal().getVisibilidad());
            //System.out.println("parte2: "+parte2);
            float guardar = (float)parte*parte2/a;
            //System.out.println("guardar: "+guardar);
            resultados[i] = guardar;
            }
          }
        //System.out.println(resultados.length);
        int b = 0;
        int c = 0;
        boolean s = false;
       
        for (int i = 0; i < resultados.length; i++) {
            if(random < resultados[i]){
                //System.out.println("random: "+ random +" resutado comparando:" + resultados[i]);
                b =i;
                break;
                }
             if(i == resultados.length-1 && resultados.length > 2){
                 //System.out.println("a");
                c++;
                random = Math.random();
                i = 0;
             }else{
               s =true;  
             }
             if(resultados.length == 2 && i == resultados.length -1){
                 //System.out.println("b");
                if(resultados[0] > resultados[1]){
                   b= 0;
                   break;
                }else{
                  b = 1;
                  break;
                }
             }
             if(resultados.length == 1 && s){
                 //System.out.println("c");
                 b = 0;
                 break;
             }
             if(c>2){
                  // System.out.println("nuevo revisar");
                if(resultados[0] > resultados[1]){
                  b= 0;
                  break;
                }else{
                 b = 1;
                 break;
                }  
            }
        }
        Camino caminocorrecto = lista.recorrer(b);
        setCamino(caminocorrecto);
        setCiudadactual(caminocorrecto.getCiudadfinal());
            if(getCiudadactual().getName()== d){
              setIntento(1);
            }
        int f = getCiudadactual().getName();
        getCamino().aumentofermonas(getGlobal().getNumerohormigas());
        Matriz m = getMatriz();
        m.cambiarvaloresespecifico(0,f,d);
        //m.Show();
        setMatriz(m);
        float e = Global.getMatrizoptimizacion().getMatrix()[f-1][d-1];
        Matriz matrizoptimizacion = Global.getMatrizoptimizacion();
        matrizoptimizacion.cambiarvaloresespecifico(e+1, f, d);
        Global.setMatrizoptimizacion(matrizoptimizacion);  
     }
    
    public boolean finalizar(){
        return getCiudadactual() == getCiudadfinal();  
    }
    
    public boolean ciega(){
        if(getIntento() == 1){
            return false;   
        }else{
            return true; 
        }
    }
    
}
