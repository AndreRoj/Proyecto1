
package Funciones;

import Interfaces.Ventana1;

public class Main {

    public static void main(String[] args) {
        Ventana1 ventana1 = new Ventana1();
        ventana1.setVisible(true);
        
    }
    
    
}
