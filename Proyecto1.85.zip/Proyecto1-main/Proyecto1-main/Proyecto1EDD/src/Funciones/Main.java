
package Funciones;

import Interfaces.Ventana1;

public class Main {

    public static void main(String[] args) {
//        Codigo de prueba de grafo, destapar

//        Matriz matrix = new Matriz(5);
//        Matriz copia = new Matriz(5);
//        Grafo grafo =  new Grafo();
//        matrix.crearmatrix();
//        matrix.cambiarvalorescolumna(5, 0);
//        matrix.cambiarvaloresespecifico(8,1,3);
//        matrix.cambiarvaloresespecifico(7, 4, 3);
//        Global global  = new Global(1,5,matrix);
//        copia.setMatrix(matrix.getMatrix());
//        grafo.setGlobal(global);
//        grafo.addValuesToGrafo();
        //matrix.print();
//        
//        for (int i = 0; i < copia.getMaximo(); i++) {
//            System.out.println(copia.buscar(1)[i]);
//        }
//        matrix.Show();
        
//        Codigo de prueba de fermonar de hormigas, probar en clases, para evitar dolores de cabeza

        /*Ciudad ciudad = new Ciudad(1);
        Ciudad ciudad2 = new Ciudad(2);
        Camino camino = new Camino(ciudad, ciudad2, 07);
        Camino camino2 = new Camino(ciudad, ciudad2, 05);
        Matriz matriz = new Matriz(5);
        Global global =  new Global(1,5,matriz);
        ciudad.setCiudadmax(5);
       Hormigas prueba  = new Hormigas(ciudad,ciudad2, matriz);
        //System.out.println(prueba.potencia(5, 5));
        matriz.crearmatrix();
        matriz.cambiarvalorescolumna(3, 1);
        matriz.cambiarvaloresfilas(3, 1);
        matriz.cambiarvalorescolumna(4, 2);
        matriz.cambiarvaloresfilas(4, 2);
        global.agregarciudad(ciudad);
        global.agregarciudad(ciudad2);
        ciudad.setCiudadmax(global.getListaciudades().getSize());
        global.getListacaminos().insertFinal(camino);
        global.getListacaminos().insertFinal(camino2);
        global.agregarfermonas();
        prueba.setGlobal(global);
 
        System.out.println("ciudad antes de eleccion");
        System.out.println(prueba.getCiudadactual().getName());
        prueba.eleccioncamino();
        System.out.println("ciudad despues de eleccion");
        System.out.println(prueba.getCiudadactual().getName());
        System.out.println("valor de fermonas");
        System.out.println(prueba.getCamino().getCantidadfermona())
    }
  }*/ 

        Ventana1 ventana1 = new Ventana1();
        ventana1.setVisible(true);
        
    }
    
    
}
