/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PruebaGrafo;

    public class Vertices {
    private Object valor;
    private Aristas arista;

    public Vertices() {
        this.valor = 0;
        this.arista = null;
    }

    public Object getValor() {
        return valor;
    }

    public void setValor(Object valor) {
        this.valor = valor;
    }

    public Aristas getArista() {
        return arista;
    }

    public void setArista(Aristas arista) {
        this.arista = arista;
    }


}
