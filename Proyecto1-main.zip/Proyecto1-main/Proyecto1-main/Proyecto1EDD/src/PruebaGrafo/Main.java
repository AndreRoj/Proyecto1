/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package PruebaGrafo;

public class Main {
    
    public static void main(String[] args) {
     int a = 0;
     while(a<20){
        double random = Math.random();
if (random<0.7 && random>0.2){
    System.out.println("1");   
}else if (random<0.2){
    System.out.println("2");   
}else{
    System.out.println("3");   
}
 a++;  
   }  
 } 
}