
package Funciones;

import Interfaces.Ventana1;

public class Main {

    public static void main(String[] args) {
//        Matriz matrix = new Matriz(5);
//        Matriz copia = new Matriz(5);
//        Grafo grafo =  new Grafo();
//        matrix.crearmatrix();
//        matrix.cambiarvalorescolumna(5, 0);
//        matrix.cambiarvaloresespecifico(8,1,3);
//        matrix.cambiarvaloresespecifico(7, 4, 3);
//        Global global  = new Global(1,5,matrix);
//        copia.setMatrix(matrix.getMatrix());
//        grafo.setGlobal(global);
//        grafo.addValuesToGrafo();
        //matrix.print();
//        
//        for (int i = 0; i < copia.getMaximo(); i++) {
//            System.out.println(copia.buscar(1)[i]);
//        }
//        matrix.Show();
        
        Ventana1 ventana1 = new Ventana1();
        ventana1.setVisible(true);
        
    }
    
    
}
